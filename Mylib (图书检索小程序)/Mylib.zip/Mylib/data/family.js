var familys = [
  {
    familyId: "f01",
    familyName: "畅销书",
    familyImg: "/img/family/bestseller.png"
  }, {
    familyId: "f02",
    familyName: "小说类",
    familyImg: "/img/family/novel.png"
  }, {
    familyId: "f03",
    familyName: "文学类",
    familyImg: "/img/family/art.png"
  }, {
    familyId: "f04",
    familyName: "历史类",
    familyImg: "/img/family/history.png"
  }, {
    familyId: "f05",
    familyName: "经济类",
    familyImg: "/img/family/economy.png"
  }, {
    familyId: "f06",
    familyName: "工具类",
    familyImg: "/img/family/tool.png"
  }
]

module.exports = {
  familys
}