Page({
  data: {
    loggedIn: false,
    userInfo: {},
    books: [
      {
        cover: "/img/books/乔布斯传.png",
        title: "乔布斯传",
        author: "沃尔特·艾萨克森"
      },
      {
        cover: "/img/books/人类简史.png",
        title: "人类简史",
        author: "尤瓦尔·赫拉利"
      },
      {
        cover: "/img/books/python.png",
        title: "Python编程-从入门到实践",
        author: "埃里克·马瑟斯"
      }
    ],
    form: {
      cover: "",
      title: "",
      author: ""
    }
  },

  onLoad: function () {
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.setData({
        loggedIn: true,
        userInfo: userInfo
      });
    }
  },

  getUserProfile: function () {
    wx.getUserProfile({
      desc: '展示用户信息',
      success: (res) => {
        const userInfo = res.userInfo;
        this.setData({
          loggedIn: true,
          userInfo: userInfo
        });
        wx.setStorageSync('userInfo', userInfo); 
      },
      fail: (err) => {
        console.error('获取用户信息失败', err);
      }
    });
  },

  logout: function () {
    wx.removeStorageSync('userInfo'); // 清除缓存的用户信息
    this.setData({
      loggedIn: false,
      userInfo: {}
    });
  },

  chooseImage: function () {
    const self = this;
    wx.chooseImage({
      count: 1,
      success: function (res) {
        self.setData({
          'form.cover': res.tempFilePaths[0]
        });
      }
    });
  },

  onInputChange: function (e) {
    const field = e.currentTarget.dataset.field;
    const value = e.detail.value;
    this.setData({
      [`form.${field}`]: value
    });
  },

  onSubmit: function (e) {
    const { cover, title, author } = this.data.form;
    if (cover && title && author) {
      const newBook = {
        cover,
        title,
        author
      };
      this.setData({
        books: [...this.data.books, newBook],
        form: {
          cover: "",
          title: "",
          author: ""
        }
      });
    } else {
      wx.showToast({
        title: '请填写所有字段',
        icon: 'none'
      });
    }
  },

  onDelete: function (e) {
    const index = e.currentTarget.dataset.index;
    const books = this.data.books;
    books.splice(index, 1);
    this.setData({
      books: books
    });
  }
});