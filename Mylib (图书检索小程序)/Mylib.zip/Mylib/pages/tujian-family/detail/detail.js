var speData = require("../../../data/spes.js");

Page({
  data: {
    commentInput: '',
    comments: []
  },

  onLoad: function (options) {
    var sid = options.sid;
    var gid = "spes_" + sid.substr(0, 6);
    var spes = speData[gid];
    var spedetail;
    spes.forEach(function (e) {
      if (e.speId == sid) {
        spedetail = e;
      }
    });
    console.log(spedetail);
    this.setData(spedetail);

    // 加载本地缓存的评价数据
    const storedComments = wx.getStorageSync(`comments_${sid}`);
    if (storedComments) {
      this.setData({
        comments: storedComments
      });
    }
  },

  bindCommentInput: function (e) {
    this.setData({
      commentInput: e.detail.value
    });
  },

  submitComment: function () {
    if (this.data.commentInput.trim() === '') {
      wx.showToast({
        title: '评价内容不能为空',
        icon: 'none'
      });
      return;
    }

    const newComments = [...this.data.comments, this.data.commentInput];
    this.setData({
      comments: newComments,
      commentInput: ''
    });

    // 保存评价数据到本地缓存
    const sid = this.data.speId;
    wx.setStorageSync(`comments_${sid}`, newComments);
  },

  deleteComment: function (e) {
    const index = e.currentTarget.dataset.index;
    const newComments = this.data.comments.filter((_, i) => i !== index);
    this.setData({
      comments: newComments
    });

    // 更新本地缓存
    const sid = this.data.speId;
    wx.setStorageSync(`comments_${sid}`, newComments);
  },

  onShareAppMessage: function () {
    // 分享逻辑
  }
});