var speData = require("../../../data/spes.js");
Page({
  data: {
    commentInput: '',
    comments: []
  },

  onLoad: function (options) {
    var sid = options.sid;
    var gid = "spes_" + sid.substr(0, 6);
    var spes = speData[gid];
    var spedetail;
    spes.forEach(function (e) {
      if (e.speId==sid){
        spedetail=e;
      }
    });
    console.log(spedetail);
    this.setData(spedetail);
  },

  bindCommentInput: function(e) {
    this.setData({
      commentInput: e.detail.value
    });
  },

  submitComment: function() {
    if (this.data.commentInput.trim() === '') {
      wx.showToast({
        title: '评价内容不能为空',
        icon: 'none'
      });
      return;
    }
    this.setData({
      comments: [...this.data.comments, this.data.commentInput],
      commentInput: ''
    });
  },

  onShareAppMessage: function () {

  }
})