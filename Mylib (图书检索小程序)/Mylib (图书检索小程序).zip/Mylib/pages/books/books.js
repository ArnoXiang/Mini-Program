Page({
  data: {
    loggedIn: false,
    userInfo: {}
  },

  onLoad: function () {
    const userInfo = wx.getStorageSync('userInfo');
    if (userInfo) {
      this.setData({
        loggedIn: true,
        userInfo: userInfo
      });
    }
  },

  goToLogin: function () {
    wx.navigateTo({
      url: '/pages/login/login'
    });
  }
});