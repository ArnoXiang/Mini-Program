var gens_f01 = [
  {
    familyId: "f01",
    genId: "f01g01",
    genName: "外国作家",
    genImg: "/img/family/foreign.png"
  }, {
    familyId: "f01",
    genId: "f01g02",
    genName: "中国作家",
    genImg: "/img/family/Chinese.png"
  
  }
]



module.exports = {
  gens_f01
}