// 99multiple.js
Page({
  data: {
    tableData: [], // 存储九九乘法表数据的二维数组
    showTable: false, // 控制九九乘法表的显示状态
    showType: '' // 控制显示类型，'asc'为升序，'desc'为降序
  },
  onLoad: function () {
    // 页面加载时不执行任何操作
  },
  showAscendingTable: function () {
    this.generateTable('asc'); // 生成升序九九乘法表
  },
  showDescendingTable: function () {
    this.generateTable('desc'); // 生成降序九九乘法表
  },
  generateTable: function (type) {
    let tableData = [];
    if (type === 'asc') {
      for (let i = 1; i <= 9; i++) {
        let row = [];
        for (let j = 1; j <= i; j++) {
          row.push(`${i}*${j}=${i * j}`);
        }
        tableData.push(row);
      }
    } else {
      for (let i = 9; i >= 1; i--) {
        let row = [];
        for (let j = i; j >= 1; j--) {
          row.push(`${i}*${j}=${i * j}`);
        }
        tableData.push(row);
      }
    }
    this.setData({
      tableData: tableData,
      showTable: true,
      showType: type
    });
  }
});
