Page({
  data: {
    id: '',
    title: '',
    author: '',
    description: ''
  },
  handleInput(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({
      [field]: e.detail.value
    });
  },
  addBook() {
    const { id, title, author, description } = this.data;
    wx.request({
      url: 'http://127.0.0.1:8008/books',
      method: 'POST',
      data: { id, title, author, description },
      success: (res) => {
        wx.showToast({
          title: '添加成功',
          icon: 'success',
          duration: 2000
        });
        // 返回并刷新数据
        wx.navigateBack({
          success: () => {
            const pages = getCurrentPages();
            const indexPage = pages[pages.length - 2];
            indexPage.fetchBooks();
            indexPage.fetchHistory();
          }
        });
      }
    });
  }
});