Page({
  data: {
    books: [],
    history: []
  },
  onLoad() {
    this.fetchBooks();
    this.fetchHistory();
  },
  fetchBooks() {
    wx.request({
      url: 'http://127.0.0.1:8008/books',
      method: 'GET',
      success: (res) => {
        this.setData({
          books: res.data
        });
      }
    });
  },
  fetchHistory() {
    wx.request({
      url: 'http://127.0.0.1:8008/history',
      method: 'GET',
      success: (res) => {
        this.setData({
          history: res.data
        });
      }
    });
  },
  navigateToAdd() {
    wx.navigateTo({
      url: '/pages/add/add'
    });
  }
});