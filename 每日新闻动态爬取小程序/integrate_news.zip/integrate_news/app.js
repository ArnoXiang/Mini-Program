// pages/news/news.js
Page({
  data: {
    newsList: []
  },

  onLoad: function () {
    this.fetchNews();
  },

  fetchNews: function () {
    const that = this;
    wx.request({
      url: 'http://v.juhe.cn/toutiao/index', // 聚合数据新闻API的URL
      method: 'GET',
      data: {
        key: '60337b7d84ce37334f59b3b1fd4154d9', // 替换成你申请到的API Key
        type: 'top' // 选择新闻类型，比如 'top' 是头条新闻
      },
      success: function (res) {
        if (res.data.error_code === 0) {
          that.setData({
            newsList: res.data.result.data
          });
        } else {
          wx.showToast({
            title: '获取新闻失败',
            icon: 'none'
          });
        }
      },
      fail: function (error) {
        wx.showToast({
          title: '请求失败',
          icon: 'none'
        });
      }
    });
  }
});