// pages/logs/logs.js
Page({
  data: {
    logs: []
  },
  onLoad: function () {
    const logs = [
      '2024-6-01 10:00:00 - User logged in',
      '2024-6-01 10:05:00 - User viewed news',
      '2024-6-01 10:15:00 - User logged out'
    ];
    this.setData({
      logs: logs
    });
  }
});