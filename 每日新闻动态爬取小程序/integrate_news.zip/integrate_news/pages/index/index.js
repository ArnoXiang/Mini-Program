// pages/index/index.js
Page({
  data: {
    // 初始化数据
  },
  onLoad: function () {
    // 页面加载时的逻辑
  }
});