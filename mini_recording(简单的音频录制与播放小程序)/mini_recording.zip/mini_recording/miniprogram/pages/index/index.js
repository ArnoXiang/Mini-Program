const recorderManager = wx.getRecorderManager();
const innerAudioContext = wx.createInnerAudioContext();

Page({
  data: {
    isSpeaking: false,
    picId: 1,
    voices: []
  },
  
  onLoad() {
    recorderManager.onStart(() => {
      console.log('recorder start');
      this.setData({
        isSpeaking: true
      });
    });

    recorderManager.onStop((res) => {
      console.log('recorder stop', res);
      const { tempFilePath } = res;
      wx.saveFile({
        tempFilePath,
        success: (result) => {
          const savedFilePath = result.savedFilePath;
          const voices = this.data.voices;
          voices.push({
            filePath: savedFilePath,
            createTime: new Date().toLocaleString(),
            size: (res.fileSize / 1024).toFixed(2)
          });
          this.setData({
            voices,
            isSpeaking: false
          });
        }
      });
    });
  },

  touchDown() {
    const options = {
      duration: 60000,
      sampleRate: 44100,
      numberOfChannels: 1,
      encodeBitRate: 192000,
      format: 'aac',
      frameSize: 50
    };
    recorderManager.start(options);
  },

  touchUp() {
    recorderManager.stop();
  },

  playAudio(e) {
    const filePath = e.currentTarget.dataset.key;
    innerAudioContext.src = filePath;
    innerAudioContext.play();
  }
});