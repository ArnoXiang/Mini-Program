Page({
  data: {
    latitude: null,
    longitude: null
  },

  onLoad: function () {
    this.mapCtx = wx.createMapContext('myMap')
  },

  getLocation: function () {
    wx.getLocation({
      type: 'wgs84',
      success: (res) => {
        console.log(res)
        wx.showToast({
          title: `纬度: ${res.latitude}, 经度: ${res.longitude}`,
          icon: 'none'
        })
      }
    })
  },

  openLocation: function () {
    wx.chooseLocation({
      success: (res) => {
        console.log(res)
        wx.showToast({
          title: `选择位置: ${res.name}`,
          icon: 'none'
        })
      }
    })
  },

  chooseLocation: function () {
    wx.openLocation({
      latitude: this.data.latitude || 23.099994,
      longitude: this.data.longitude || 113.324520,
      scale: 18
    })
  },

  getCenterLocation: function () {
    this.mapCtx.getCenterLocation({
      success: (res) => {
        console.log(res)
        wx.showToast({
          title: `中心位置: 纬度: ${res.latitude}, 经度: ${res.longitude}`,
          icon: 'none'
        })
      }
    })
  },

  moveToLocation: function () {
    this.mapCtx.moveToLocation()
  }
})