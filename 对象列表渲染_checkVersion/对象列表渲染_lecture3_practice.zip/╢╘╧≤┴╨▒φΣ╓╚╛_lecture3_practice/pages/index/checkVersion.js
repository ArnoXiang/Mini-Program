// test.js

Page({
  data: {
    device: {
      brand: 'Apple', // 假设设备品牌为Apple
      color: 'Silver',
      model: 'iPhone 14 pro',
      screenSize: '6.1 inches',
      screenResolution: '2532 x 1170',
      cpuFrequency: '2.99 GHz',
      memorySize: '4 GB'
    },
    deviceType: 'Unknown' // 默认设备类型为Unknown
  },
  onLoad: function () {
    // 页面加载时不再执行设备类型判断
  },
  // 新增方法，用于按钮点击事件
  checkDeviceType: function () {
    // 判断设备类型
    if (this.data.device.brand === 'Apple') {
      this.setData({
        deviceType: 'Apple'
      });
    } else if (this.data.device.brand === 'Android') {
      this.setData({
        deviceType: 'Android'
      });
    } else if (this.data.device.brand === 'Windows') {
      this.setData({
        deviceType: 'Windows'
      });
    }
  }
});

